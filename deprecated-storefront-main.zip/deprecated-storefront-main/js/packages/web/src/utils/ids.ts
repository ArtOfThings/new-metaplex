import { PublicKey } from '@solana/web3.js';

// TODO: generate key ---
export const AR_SOL_HOLDER_ID = new PublicKey(
  '6FKvsq4ydWFci6nGq9ckbjYMtnmaqAoatz5c9XWjiDuS',
);
