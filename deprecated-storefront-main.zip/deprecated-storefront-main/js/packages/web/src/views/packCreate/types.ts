export enum CreatePackSteps {
  SelectItems,
  SelectVoucher,
  AdjustQuantities,
  ReviewAndMint,
}
