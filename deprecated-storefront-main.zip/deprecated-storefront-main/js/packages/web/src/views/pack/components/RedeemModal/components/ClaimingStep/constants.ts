export const CARDS_DISTANCE = 16;

export const INFO_MESSAGES = [
  'You may also have to approve the purchase in your wallet if you don’t have “auto-approve” turned on.',
  'Cards are randomly distributed to ensure an equal chance to receive any card. It may take up to a few seconds to fetch each Card.',
];
