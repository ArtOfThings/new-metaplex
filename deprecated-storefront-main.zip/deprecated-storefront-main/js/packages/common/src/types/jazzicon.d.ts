declare module '@metamask/jazzicon' {
  const jazzicon: any;
  export = jazzicon;
}
