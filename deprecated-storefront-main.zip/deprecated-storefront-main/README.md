# Metaplex Storefront

🚨 **Deprecated Repo** 🚨

Please note that this GitHub repository is no longer being maintained.


## About

Metaplex storefront is a self-hosted front-end web3 application.

You can check out our docs at https://docs.metaplex.com/

## Installing

Clone the repo, and run `yarn start` to deploy.

```bash
$ git clone https://github.com/metaplex-foundation/storefront-deprecated.git
$ cd metaplex/js
$ yarn install && yarn bootstrap && yarn build
$ yarn start
```

Navigate to `http://localhost:3000/` to explore the deployed application.

## Community

We have a few channels for contact:

- [Discord](https://discord.gg/metaplex)
- [@metaplex](https://twitter.com/metaplex) on Twitter
